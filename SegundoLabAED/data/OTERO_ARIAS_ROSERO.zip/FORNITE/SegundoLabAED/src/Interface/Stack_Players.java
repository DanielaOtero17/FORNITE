package Interface;

public interface Stack_Players<T>{
	
	public T getT();
	public int longitude();
	public boolean isEmpty();
    public T getTop();
    public boolean search(T o);
    public void remove(T o);  
}
